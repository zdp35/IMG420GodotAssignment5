# GodotAssignment5 (Ready-to-Import)

**Godot 4.x + C#** project implementing:
1) Custom canvas shader + GPU particles
2) Physics rope/chain via `DampedSpringJoint2D`
3) Raycast laser with Line2D visualization + player alarm

## Import
- Unzip, open folder in Godot 4.x (with C#/.NET installed).
- Godot will auto-detect `project.godot` and build the C# solution.
- Run `Scenes/Main.tscn` (set as main in `project.godot`).

## Notes
- Layers: World(1), Player(2), Chain(3), Laser(4) set in `project.godot`.
- Player group is added at runtime in `Player.cs`.
- Laser color/length configurable in `LaserDetector` exports.
- Chain segment scene assigned in `Scenes/Main.tscn` to `ChainRoot` export.

Test impulses (Editor console): `@"/root/Main/PhysicsDemo/ChainRoot".ApplyForceToSegment(3, Vector2(0,-300))`