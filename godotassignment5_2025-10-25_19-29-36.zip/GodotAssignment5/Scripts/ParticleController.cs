using Godot;

public partial class ParticleController : GpuParticles2D
{
    private ShaderMaterial _mat;

    [Export] public float WaveIntensity = 0.12f;
    [Export] public Color ColorStart = new Color(1f, 0.5f, 0f);
    [Export] public Color ColorEnd   = new Color(1f, 0f, 0.5f);
    private float _t;

    public override void _Ready()
    {
        var shader = GD.Load<Shader>("res://Shaders/custom_particle.gdshader");
        _mat = new ShaderMaterial { Shader = shader };
        Material = _mat;

        Amount = 300;
        Lifetime = 2.2f;
        OneShot = false;
        Preprocess = 1.5f;
        SpeedScale = 1.0f;
        Emitting = true;

        var pm = new ParticleProcessMaterial
        {
            Direction = new Vector3(0, -1, 0),
            Spread = 0.7f,
            InitialVelocityMin = 60,
            InitialVelocityMax = 120,
            Gravity = new Vector3(0, 40, 0),
            AngularVelocityMin = -1.5f,
            AngularVelocityMax = 1.5f,
            DampingMin = 0.0f,
            DampingMax = 0.2f
        };
        ProcessMaterial = pm;

        _mat.SetShaderParameter("wave_intensity", WaveIntensity);
        _mat.SetShaderParameter("color_start", ColorStart);
        _mat.SetShaderParameter("color_end", ColorEnd);
    }

    public override void _Process(double delta)
    {
        _t += (float)delta;
        _mat?.SetShaderParameter("user_time", _t);
        var w = WaveIntensity * (0.85f + 0.15f * Mathf.Sin(_t * 2.0f));
        _mat?.SetShaderParameter("wave_intensity", w);
    }
}