using Godot;

public partial class LaserDetector : Node2D
{
    [Export] public float LaserLength = 500f;
    [Export] public Color LaserColorNormal = Colors.Green;
    [Export] public Color LaserColorAlert  = Colors.Red;
    [Export] public NodePath PlayerPath;

    private RayCast2D _rayCast;
    private Line2D _beam;
    private Node2D _player;
    private bool _alarming = false;
    private Timer _alarmTimer;

    public override void _Ready()
    {
        SetupRaycast();
        SetupVisuals();

        _player = GetNodeOrNull<Node2D>(PlayerPath);
        _alarmTimer = new Timer { OneShot = true, WaitTime = 0.7 };
        AddChild(_alarmTimer);
        _alarmTimer.Timeout += ResetAlarm;
    }

    private void SetupRaycast()
    {
        _rayCast = new RayCast2D
        {
            Enabled = true,
            TargetPosition = new Vector2(LaserLength, 0)
        };
        _rayCast.SetCollisionMaskValue(1, true);
        _rayCast.SetCollisionMaskValue(2, true);
        AddChild(_rayCast);
    }

    private void SetupVisuals()
    {
        _beam = new Line2D
        {
            Width = 3f,
            DefaultColor = LaserColorNormal,
            Antialiased = true
        };
        _beam.Points = new Vector2[] { Vector2.Zero, new Vector2(LaserLength, 0) };
        AddChild(_beam);
    }

    public override void _PhysicsProcess(double delta)
    {
        _rayCast.ForceRaycastUpdate();

        Vector2 end = new Vector2(LaserLength, 0);
        if (_rayCast.IsColliding())
        {
            end = ToLocal(_rayCast.GetCollisionPoint());
            var hit = _rayCast.GetCollider();
            bool hitPlayer = hit is Node n && n.IsInGroup("Player");
            if (hitPlayer) TriggerAlarm();
        }
        UpdateLaser(end);
    }

    private void UpdateLaser(Vector2 localEnd)
    {
        _beam.Points = new Vector2[] { Vector2.Zero, localEnd };
    }

    private void TriggerAlarm()
    {
        if (_alarming) return;
        _alarming = true;
        _beam.DefaultColor = LaserColorAlert;
        var tween = CreateTween();
        tween.TweenProperty(this, "modulate:a", 0.4f, 0.15f).From(1.0f);
        tween.TweenProperty(this, "modulate:a", 1.0f, 0.15f);
        GD.Print("ALARM! Player detected!");
        _alarmTimer.Start();
    }

    private void ResetAlarm()
    {
        _alarming = false;
        _beam.DefaultColor = LaserColorNormal;
        Modulate = Colors.White;
    }
}