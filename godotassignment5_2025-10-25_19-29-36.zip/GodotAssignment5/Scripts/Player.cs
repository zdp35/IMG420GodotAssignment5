using Godot;

public partial class Player : CharacterBody2D
{
    [Export] public float Speed = 220f;

    public override void _Ready()
    {
        AddToGroup("Player");
        SetCollisionLayerValue(2, true);
        SetCollisionMaskValue(1, true);
        SetCollisionMaskValue(4, true);
    }

    public override void _PhysicsProcess(double delta)
    {
        Vector2 v = Vector2.Zero;
        if (Input.IsActionPressed("ui_left"))  v.X -= 1;
        if (Input.IsActionPressed("ui_right")) v.X += 1;
        if (Input.IsActionPressed("ui_up"))    v.Y -= 1;
        if (Input.IsActionPressed("ui_down"))  v.Y += 1;

        Velocity = v.Normalized() * Speed;
        MoveAndSlide();
    }
}