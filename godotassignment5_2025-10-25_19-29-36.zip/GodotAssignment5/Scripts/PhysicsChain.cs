using Godot;
using System.Collections.Generic;

public partial class PhysicsChain : Node2D
{
	[Export] public int ChainSegments = 6;
	[Export] public float SegmentDistance = 28f;
	[Export] public PackedScene SegmentScene;

	private readonly List<RigidBody2D> _segments = new();
	private readonly List<Joint2D> _joints = new();

	public override void _Ready() => CreateChain();

	private void CreateChain()
	{
		if (SegmentScene == null)
		{
			GD.PushError("SegmentScene not assigned.");
			return;
		}

		var anchor = new StaticBody2D
		{
			Name = "Anchor",
			Position = GlobalPosition
		};
		AddChild(anchor);

		Vector2 basePos = GlobalPosition + new Vector2(0, 40);
		for (int i = 0; i < ChainSegments; i++)
		{
			var seg = SegmentScene.Instantiate<RigidBody2D>();
			seg.GlobalPosition = basePos + new Vector2(0, i * SegmentDistance);
			seg.SetCollisionLayerValue(3, true); // Chain
			seg.SetCollisionMaskValue(1, true);  // World
			seg.SetCollisionMaskValue(2, true);  // Player
			AddChild(seg);
			_segments.Add(seg);

			Node2D nodeA = (i == 0) ? anchor : _segments[i - 1];
			var joint = new DampedSpringJoint2D
			{
				Name = $"Joint_{i}",
				NodeA = nodeA.GetPath(),
				NodeB = seg.GetPath(),
				RestLength = SegmentDistance,
				Stiffness = 60.0f,
				Damping = 8.0f
			};
			AddChild(joint);
			_joints.Add(joint);
		}
	}

	public void ApplyForceToSegment(int segmentIndex, Vector2 force)
	{
		if (segmentIndex < 0 || segmentIndex >= _segments.Count) return;
		_segments[segmentIndex].ApplyCentralImpulse(force);
	}
}
